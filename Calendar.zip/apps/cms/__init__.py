#encoding: utf-8

from .views import bp