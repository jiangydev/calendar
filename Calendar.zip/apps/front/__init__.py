#encoding: utf-8

from .views import bp
import apps.front.hocks