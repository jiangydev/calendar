#encoding: utf-8

'''
here is the configure file of project calendar
'''

from datetime import timedelta
import os

# 开启debug模式
DEBUG = True
# 模板修改自动导入
TEMPLATES_AUTO_RELAOD = True


HOSTNAME = '127.0.0.1'
PORT = '3306'
DATABASE = 'calendar'
USERNAME = 'root'
PASSWORD = 'Pass2018@hdf'

# dialect+driver://username:password@host:port/database
DB_URI = "mysql+pymysql://{username}:{password}@{host}:{port}/{db}?charset=utf8mb4".format(username=USERNAME,password=PASSWORD,host=HOSTNAME,port=PORT,db=DATABASE)
SQLALCHEMY_DATABASE_URI = DB_URI
SQLALCHEMY_TRACK_MODIFICATIONS = False

# 如果用户选择“记住我”，则session保存7天
PERMANENT_SESSION_LIFETIME = timedelta(days=7)

# SECRET_KEY = os.urandom(24)
# 用于解析session，
# 测试时设为常量可以避免每次重启服务器后需要重新登录
SECRET_KEY = 'temp secret key'

CMS_USER_ID = 'CMS_USER_ID'
# 统一配置session中cms用户的key名称，方便后期修改以及防止程序中单独写写错
# 值可以随便取，注意不要与其他重复
FRONT_USER_ID = 'FRONT_USER_ID'

'''
flask-mail配置
'''
# qq
# # 发送者邮件的服务器地址
# MAIL_SERVER = 'smtp.qq.com'
# # 不加密的端口默认25
# # 加密的有两种协议,端口号如下
# # MAIL_USE_TLS: 587
# # MAIL_USER_SSL: 465
# MAIL_PORT = 465
# # MAIL_USE_TLS = True     # 使用MAIL_USE_TLS协议
# MAIL_USE_SSL = True
# # MAIL_DEBUG : default app.debug
# MAIL_USERNAME = '1514640961@qq.com'
# MAIL_PASSWORD = 'vqwlybgnsrekifij'  # 授权码
# MAIL_DEFAULT_SENDER = '1514640961@qq.com'

# 163
MAIL_SERVER = 'smtp.163.com'
MAIL_PORT = 465
MAIL_USE_SSL = True
MAIL_USERNAME = 'shirleyonpython@163.com'
MAIL_PASSWORD = 'humoufeng163'
MAIL_DEFAULT_SENDER = 'shirleyonpython@163.com'

'''
云片短信服务配置
'''
YUNPIAN_APIKEY = 'b33e98b4126ff268a746355dc7b3d33c'